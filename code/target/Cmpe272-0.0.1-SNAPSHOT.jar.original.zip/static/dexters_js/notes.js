
$(document).ready(function() {

	Notes()

});

