
$(document).ready(function() {

//notes.js

});

